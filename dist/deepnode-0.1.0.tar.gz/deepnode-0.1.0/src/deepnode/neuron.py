import math
import random

class Neuron:
    """
    A single neuron implementation for a neural network.
    
    This class represents a basic artificial neuron that can:
    - Accept multiple inputs
    - Apply weights to each input
    - Add a bias term
    - Apply an activation function
    - Return a single output
    """
    
    def __init__(self, weights=None, bias=0.0, activation='sigmoid'):
        """
        Initialize the neuron with weights, bias, and activation function.
        
        Args:
            weights (list): List of weights for each input connection
            bias (float): Bias value to be added before activation
            activation (str): Type of activation function to use
        """
        self.weights = weights if weights is not None else []
        self.weight_velocities = [0.0] * len(self.weights)  # For momentum-based updates
        self.bias = bias
        self.bias_velocity = 0.0  # For momentum-based updates
        self.weight_gradient_accumulations = [0.0] * len(self.weights)  # For accumulating gradients during backpropagation
        self.weight_squared_gradient_accumulations = [0.0] * len(self.weights)  # For adaptive learning rates (e.g., AdaGrad)
        self.bias_gradient_accumulation = 0.0  # For accumulating bias gradients during backpropagation
        self.bias_squared_gradient_accumulation = 0.0  # For adaptive learning rates (e.g., AdaGrad)
        self.activation = activation
        
        # Store the last computed values for debugging purposes
        self.last_inputs = None
        self.last_weighted_sum = None
        self.last_output = None

        # Dropout mask applied on the most recent forward pass:
        # 0.0 if this neuron was dropped, otherwise 1.0 / (1.0 - dropout_rate)
        # (or 1.0 when no dropout was used). Backprop must multiply by this
        # so that dropped neurons contribute zero gradient, matching the fact
        # that they contributed zero output.
        self.last_dropout_mask = 1.0

        # Node value = ∂Cost/∂(weighted_sum) for this neuron
        self.node_value = 0.0

    
    def sigmoid(self, x):
        """
        Sigmoid activation function: f(x) = 1 / (1 + e^(-x))
        
        This function maps any real number to a value between 0 and 1.
        Commonly used for binary classification problems.
        
        Args:
            x (float): Input value to the activation function
            
        Returns:
            float: Output value between 0 and 1
        """
        # Prevent overflow by clipping extreme values
        if x > 500:
            return 1.0
        elif x < -500:
            return 0.0
        else:
            return 1.0 / (1.0 + math.exp(-x))
    
    def relu(self, x):
        """
        ReLU (Rectified Linear Unit) activation function: f(x) = max(0, x)
        
        This function returns the input if positive, otherwise returns 0.
        Commonly used in hidden layers of deep networks.
        
        Args:
            x (float): Input value to the activation function
            
        Returns:
            float: Output value (0 if input is negative, input value if positive)
        """
        return max(0.0, x)
    
    def leaky_relu(self, x):
        """
        Leaky ReLU activation function: f(x) = max(0.01*x, x)
        
        This function allows a small gradient when the input is negative,
        which can help prevent "dying ReLU" problems in deep networks.
        
        Args:
            x (float): Input value to the activation function
            
        Returns:
            float: Output value (0.01*x if input is negative, input value if positive)
        """
        return x if x > 0 else 0.01 * x
    
    def tanh(self, x):
        """
        Hyperbolic tangent activation function: f(x) = tanh(x)
        
        This function maps any real number to a value between -1 and 1.
        Similar to sigmoid but centered around 0.
        
        Args:
            x (float): Input value to the activation function
            
        Returns:
            float: Output value between -1 and 1
        """
        return math.tanh(x)
    
    def linear(self, x):
        """
        Linear activation function: f(x) = x
        
        This function returns the input unchanged.
        Used in regression problems or output layers.
        
        Args:
            x (float): Input value to the activation function
            
        Returns:
            float: Input value unchanged
        """
        return x
    
    def exponential(self, x):
        """
        Exponential activation function: f(x) = e^x
        
        This function maps any real number to a positive value.
        Can be used in certain types of networks or output layers.
        
        Args:
            x (float): Input value to the activation function
        """
        return math.exp(x)
    
    def apply_activation(self, x):
        """
        Apply the specified activation function to the input.
        
        Args:
            x (float): Input value to apply activation to
            
        Returns:
            float: Result after applying the activation function
        """
        if self.activation == 'sigmoid':
            return self.sigmoid(x)
        elif self.activation == 'relu':
            return self.relu(x)
        elif self.activation == 'leaky_relu':
            return self.leaky_relu(x)
        elif self.activation == 'tanh':
            return self.tanh(x)
        elif self.activation == 'linear':
            return self.linear(x)
        elif self.activation == 'exponential':
            return self.exponential(x)
        else:
            # Default to sigmoid if unknown activation function
            print(f"Warning: Unknown activation function '{self.activation}'. Using sigmoid.")
            return self.sigmoid(x)
    
    def forward(self, inputs, dropout_rate=0.0):
        """
        Perform the forward pass through the neuron.
        
        This method implements the core neuron computation:
        1. Multiply each input by its corresponding weight
        2. Sum all weighted inputs
        3. Add the bias term
        4. Apply the activation function
        5. Return the final output
        
        Args:
            inputs (list): List of input values
            
        Returns:
            float: The neuron's output after processing
            
        Raises:
            ValueError: If the number of inputs doesn't match the number of weights
        """
        # Validate input dimensions
        if len(inputs) != len(self.weights):
            raise ValueError(f"Number of inputs ({len(inputs)}) must match number of weights ({len(self.weights)})")
        
        # Store inputs for debugging
        self.last_inputs = inputs.copy()
        
        # Step 1: Calculate the weighted sum of inputs
        # This is the dot product of inputs and weights: Σ(input_i * weight_i)
        weighted_sum = 0.0
        for i in range(len(inputs)):
            weighted_sum += inputs[i] * self.weights[i]
        
        # Step 2: Add the bias term
        # The bias allows the neuron to shift the activation function
        weighted_sum += self.bias
        
        # Store the weighted sum for debugging
        self.last_weighted_sum = weighted_sum
        
        # Step 3: Check for dropout and apply the activation function
        # This introduces non-linearity to the neuron's output
        if random.random() < dropout_rate:
            # This neuron is dropped for this forward pass. Remember that via
            # last_dropout_mask so backpropagation can zero out its gradient
            # too, instead of only zeroing the forward output.
            self.last_dropout_mask = 0.0
            output = 0.0
        else:
            # Scale output to maintain expected value (inverted dropout).
            # The same scale factor is remembered so backprop can apply it
            # to the gradient, keeping forward and backward consistent.
            self.last_dropout_mask = 1.0 / (1.0 - dropout_rate)
            output = self.apply_activation(weighted_sum) * self.last_dropout_mask
        
        # Store the output for debugging
        self.last_output = output
        
        return output
    
    def set_weights(self, weights):
        """
        Set new weights for the neuron.
        
        Args:
            weights (list): New list of weights
        """
        self.weights = weights.copy()
    
    def set_bias(self, bias):
        """
        Set a new bias value for the neuron.
        
        Args:
            bias (float): New bias value
        """
        self.bias = bias
    
    def get_info(self):
        """
        Get information about the neuron's current state.
        
        Returns:
            dict: Dictionary containing neuron information
        """
        return {
            'weights': self.weights,
            'bias': self.bias,
            'activation': self.activation,
            'last_inputs': self.last_inputs,
            'last_weighted_sum': self.last_weighted_sum,
            'last_output': self.last_output,
            'last_dropout_mask': self.last_dropout_mask,
            'node_value': self.node_value
        }